public class Doll {
    private String name;
    private String material;
    private double price;
    
    public Doll(String name, String material, double price){
        this.name = name;
        this.material = material;
        this.price = price;
    }

    public String toString(){
        return this.name;
    }
    
    public void play(){
        System.out.print("I don't know. How to play");
    }

    public static void main(String[] args){
        Doll d1  = new Doll("Anda", "Plastic", 50.0);
        System.out.println(d1);
        d1.play();
    }

    public void displayInfo(){
        System.out.println("Name: " + name);
        System.out.println("Material:" + material);
        System.out.println("Price: $" + price);
    }

    public boolean isFragile(){
        if (material.equals("Porecelain") || material.equals("Glass")){
            return true;
        } else {
            return false;
        }
    }
}