// This is the App.java file
import java.util.Objects;

public class Doll {
    private final String name;
    private final String material;
    private final double price;

    public Doll(String name, String material, double price){
        this.name = name;
        this.material = material;
        this.price = price;
    }
    public String toString(){
        return name;

    }
    public void play(){
        System.out.println("I don't know. Howw to play");
    }
    public void displayInfo(){
        System.out.println("Name: " + name);
        System.out.println("Material: " + material);
        System.out.println("Price: $" + price);
    }
    public boolean isFragile(){
        return Objects.equals(material, "Porcelian") || Objects.equals(material, "glass");
    }
    
}