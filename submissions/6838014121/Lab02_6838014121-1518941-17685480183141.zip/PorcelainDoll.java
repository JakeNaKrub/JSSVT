public class PorcelainDoll extends Doll{
    public PorcelainDoll(String name, double price){
        super(name, "Porcelain", price);
    }
    @Override
    public void play(){
        System.out.println("This doll is fragile. Not playing with it.");
    }
}
