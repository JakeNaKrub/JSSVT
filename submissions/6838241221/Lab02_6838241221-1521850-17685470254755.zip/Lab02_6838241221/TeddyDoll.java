package LAB2;

public class TeddyDoll extends Doll{
    public TeddyDoll(String name,double price){
       super(name,"Cotton",price); 
    }
    public void play(){
        System.out.println("Teddy Doll says: Hug me!");
    }
}
