public class TeddyDoll extends Doll {
    
    public TeddyDoll(String name, double price) {
        this.name = name;
        this.price = price;
        this.material = "Fur";
    }
    
    public void play() {
        System.out.println("Teddy Doll says: Hug me!");
    }
}
