public class Barbie extends Doll {
    
    public Barbie(String name, double price) {
        this.name = name;
        this.price = price;
        this.material = "Plastic";
    }
    
    public void play() {
        System.out.println("Barbie sings: I'm a Barbie girl in a Barbie world!");
    }
}
