public class PorcelainDoll extends Doll {
    
    public PorcelainDoll(String name, double price) {
        this.name = name;
        this.price = price;
        this.material = "Porcelain";
    }
    
    public void play() {
        System.out.println("Porcelain Doll is delicate, be gentle!");
    }
}
