public class Doll {
    String name;
    String material;
    double price;

    public String toString() {
        return name;
    }

    public void play() {
        System.out.println("I don't know. How to play");
    }

    public void displayInfo() {
        System.out.println("Name: "+ name + "\nMaterial: "+ material + "\nPrice: " + price);
    }
    
    public boolean isFragile() {
        if((material.equals("Porcelain")) || (material.equals("Glass"))) { // and, or, not in python are &&, ||, and ! respectively in Java
            return true;
        }
        else {
            return false;
        }
    }

}
