public class PorcelainDoll extends Doll{
    public PorcelainDoll(String name, double price) {
        super(name, "Porcelain", price);
    }

    public void play(){
        System.out.println("Porcelain doll is delicate, be gentle!");
    }
}