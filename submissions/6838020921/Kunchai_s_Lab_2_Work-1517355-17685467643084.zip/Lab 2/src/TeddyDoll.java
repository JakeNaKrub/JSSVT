public class TeddyDoll extends Doll {
    public TeddyDoll(String name, double price) {
        super(name, "Fabric", price);
    }
    @Override
    public Void play() {
        System.out.println("Teddy bear says: Hug me!");
        return null;
    }
}