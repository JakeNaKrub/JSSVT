public class Doll {
    private String name;
    private String material;
    private double price;

    public Doll(String name, double price) {
        this.name = name;
        this.price = price;
    }

    public String toString() {
        return(this.name);
    }

    public void play() {
        System.out.println("I don't know. How to play");

    }

    public void setMeterial(String meterial){
        this.material = meterial;
    }

    public void displayInfo() {
        System.out.println("Name: " + this.name);
        System.out.println("Material: " + this.material);
        System.out.println("Price: $"+ this.price);
    }

    public boolean isFragile() {
        if(material.equals("Porcelain")|| material.equals("Glass")){
            return(true);
        }
        else{
            return(false);
        }

    }
}

