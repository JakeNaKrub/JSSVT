public class TeddyDoll extends Doll {

    public TeddyDoll(String name, double price) {
        super(name, price, "Fur");
    }

    public void play(){
        System.out.println("Teddy Doll says: Hug me!");
    }

}
