public class TeddyDoll extends Doll{
    public TeddyDoll(String name, float price){
        super(name, "Fur", price);
    }

    public void play(){
        System.out.println("Teddy Doll says: Hug me!");
    }
}
