public class Doll {
    private String name;
    private String material;
    private double price;

    // Constructor
    public Doll(String name, String material, double price) {
        this.name = name;
        this.material = material;
        this.price = price;
    }

    // toString method
    public String toString() {
        return name;
    }

    // play method
    public void play() {
        System.out.println("I don't know. How to play");
    }

    // displayInfo method
    public void displayInfo() {
        System.out.println("Name: " + name + "\nMaterial: " + material + "\nPrice: $" + price);
    }

    // isFragile method
    public boolean isFragile() {
        return material.equals("Porcelain") || material.equals("Glass");
      
    }
}
