public class Teddydoll extends Doll {
    public Teddydoll(String name, double price) {
        super(name, "Fur", price);
    }
    
    public void play() {
        System.out.println("Teddy Doll says: Hug me!");
    }
}
