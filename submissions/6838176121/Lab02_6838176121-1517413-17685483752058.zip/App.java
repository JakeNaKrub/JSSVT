public class App {
    public static void main(String[] args) {
        Doll[] dolls = new Doll[5];

        dolls[0] = new Barbie("Barbie1", 29.99);
        dolls[1] = new Barbie("Barbie2", 34.99);
        dolls[2] = new Teddydoll("Teddy", 19.99);
        dolls[3] = new Porcelaindoll("Porcelain1", 49.99);
        dolls[4] = new Porcelaindoll("Porcelain2", 59.99);

        for (Doll doll : dolls) {
            doll.displayInfo();
            if (!doll.isFragile()) {
                doll.play();
            } else {
                System.out.println("This doll is fragile. Not playing with it.");
            }
            System.out.println();
        }
    }
}