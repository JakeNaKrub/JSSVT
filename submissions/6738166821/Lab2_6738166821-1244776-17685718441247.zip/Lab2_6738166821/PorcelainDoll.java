package Lab2_6738166821;

public class PorcelainDoll extends Doll {
    public PorcelainDoll(String name, float price) {
        super(name, "Porcelain", price);
    }

    
}
