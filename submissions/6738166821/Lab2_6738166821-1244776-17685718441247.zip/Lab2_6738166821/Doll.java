package Lab2_6738166821;

public class Doll{
private String name;
private String material;
private double price;

public Doll(String name,String material, double price) { 
    this.name= name;
    this.material = material;
    this.price = price;
    }
    public String toString() {
        return ("Name: "+name);
    }
    public void play() {
        System.out.println("I don't know. How to play");
    }
    public void displayInfo(){
        System.out.println("Name: "+name);
        System.out.println("Material: "+material);
        System.out.println("Price: "+price);
    }
    public boolean isFragile(){
        if(this.material.equals("Porcelain")){
            return true;
        }
        return false;
    }

public void setName(String name){
    this.name = name;
}
public void setMaterial(String material){
    this.material = material;
}
public void setPrice(double price){
    this.price = price;
}
public String getName(){
    return this.name;
}

public String getMaterial(){
    return this.material;
}

public double getPrice(){
    return this.price;
}


}
