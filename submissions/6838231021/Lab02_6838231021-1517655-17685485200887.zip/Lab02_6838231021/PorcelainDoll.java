public class PorcelainDoll extends Doll {

    public PorcelainDoll(String name, double price) {
        super(name,"Porcelain", price);
    }

    public void play() {
        System.out.println("Barbie sings: I'm a Barbie girl in a Barbie world!");
    }
}
