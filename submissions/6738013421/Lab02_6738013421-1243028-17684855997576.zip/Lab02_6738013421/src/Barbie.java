public class Barbie extends Doll {

    public Barbie(String name, double price) {
        super(name,"Plastic",price);
    }

    @Override
    public void play() {
        System.out.println("Barbie sings: I'm a Barbie girl in a Barbie world!");
    }
}