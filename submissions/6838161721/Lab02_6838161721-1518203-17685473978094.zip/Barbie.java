public class Barbie extends Doll { 
    public Barbie(String name, double price) {
        super(name, "Plastic", price);
        //didnt have to write material inside
        //Barbie bc all barbies have same material
    }
    //OVERRIDE THE INITIAL DOLL PLAY METHOD
    //SO NOW A SPECIFIC BARBIE WILL ONLY 
    //SAY WHAT IS INSIDE THIS METHOD
    public void play() {
        System.out.print("Barbie sings: I'm a Barbie girl in a Barbie world!");
    }
}
