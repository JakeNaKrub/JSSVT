public class Barbie extends Doll {

    public Barbie(String name, double price) {
        super(name, price);
        setMaterial("Plastic");
    }

    @Override
    public void play() {
        System.out.println("I'm a Barbie girl in a Barbie world!");
    }

}