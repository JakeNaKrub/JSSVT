public class PorcelainDoll extends Doll {
    
    public PorcelainDoll(String name,float price)
    {
        super(name,price);
        setMaterial("Porcelain");
    }
@Override
    public void play(){
       System.out.println("PorcelainDoll sings: Porcelain Doll is delicate, be gentle!"); 
    }
}
