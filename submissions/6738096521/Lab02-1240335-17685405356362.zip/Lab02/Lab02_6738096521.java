public class Lab02_6738096521 {
    public static void main(String[] args) {
        Doll[] dolls = new Doll[5];

        dolls[0] = new Barbie("Barbie1", 29.99f);
        dolls[1] = new Barbie("Barbie2", 34.99f);
        dolls[2] = new TeddyDoll("Teddy", 19.99f);
        dolls[3] = new PorcelainDoll("Porcelain1", 49.99f);
        dolls[4] = new PorcelainDoll("Porcelain2", 59.99f);

        for (Doll doll : dolls) {
            doll.displayInfo();
            if (!doll.isFragile()) {
                doll.play();
            } else {
                System.out.println("This doll is fragile. Not playing with it.");
            }
            System.out.println();
        }
    }
}

// Doll class
class Doll {
    private String name;
    private String material;
    private double price;

    public Doll(String name, String material, float price) {
        this.name = name;
        this.material = material;
        this.price = price;
    }

    public String toString() {
        return name;
    }

    public void play() {
        System.out.println("I don't know. How to play");
    }

    public void displayInfo() {
        System.out.println("Name: " + name);
        System.out.println("Material: " + material);
        System.out.println("Price: $" + price);
    }

    public boolean isFragile() {
        if (material.equals("Porcelain") || material.equals("Glass")) {
            return true;
        } else {
            return false;
        }
    }
}

// Barbie 
class Barbie extends Doll {
    public Barbie(String name, float price) {
        super(name, "Plastic", price);
    }

    public void play() {
        System.out.println("Barbie sings: I'm a Barbie girl in a Barbie world!");
    }
}

// TeddyDoll 
class TeddyDoll extends Doll {
    public TeddyDoll(String name, float price) {
        super(name, "Fur", price);
    }

    public void play() {
        System.out.println("Teddy Doll says: Hug me!");
    }
}

//  PorcelainDoll 
class PorcelainDoll extends Doll {
    public PorcelainDoll(String name, float price) {
        super(name, "Porcelain", price);
    }

    public void play() {
        System.out.println("Porcelain Doll is delicate, be gentle!");
    }
}
