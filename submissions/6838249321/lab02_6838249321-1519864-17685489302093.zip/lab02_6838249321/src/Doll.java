public class Doll {
    protected String name;
    protected String material;
    protected double price;

    public Doll(String name, String material, double price) {
        this.name = name;
        this.material = material;
        this.price = price;
    }

    public void play() {
        System.out.println("I don't know. How to play");
    }

    public void displayInfo() {
        System.out.println("Name: " + name);
        System.out.println("Material: " + material);
        System.out.println("Price: $" + price);
    }

    public boolean isFragile() {
        return material.equals("Porcelain") || material.equals("Glass");
    }
}

