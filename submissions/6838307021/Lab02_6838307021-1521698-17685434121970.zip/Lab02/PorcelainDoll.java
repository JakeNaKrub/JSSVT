public class PorcelainDoll extends Doll {

    public PorcelainDoll(String doll_name, double doll_price) {
        super(doll_name, "Porcelain", doll_price);
    }

    public void play() {
        System.out.println("Porcelain Doll is delicate, be gentle!");
    }
}
