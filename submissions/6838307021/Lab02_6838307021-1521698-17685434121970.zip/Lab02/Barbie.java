public class Barbie extends Doll {
    
    public Barbie (String doll_name, double doll_price) {
        super(doll_name, "Plastic", doll_price);
    }

    public void play() {
        System.out.println("Barbie sings: I\'m a Barbie girl in a Barbie world!");
    }

}
