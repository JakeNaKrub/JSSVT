public class TeddyDoll extends Doll {

    public TeddyDoll(String doll_name, double doll_price) {
        super(doll_name, "Fur", doll_price);
    }

    public void play() {
        System.out.println("Teddy Doll says: Hug me!");
    }
}
