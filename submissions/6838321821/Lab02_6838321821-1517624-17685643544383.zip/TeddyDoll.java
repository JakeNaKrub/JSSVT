public class TeddyDoll extends Doll {
  public TeddyDoll(String _name, double _price){
    super(_name, "Fur", _price);
  }
  
  public void play() {
    System.out.println("Teddy Doll says: Hug me!");
  }
}
