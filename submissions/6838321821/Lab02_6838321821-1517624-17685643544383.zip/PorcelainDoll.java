public class PorcelainDoll extends Doll {
  public PorcelainDoll(String _name, double _price){
    super(_name, "Porcelain", _price);
  }
  
  public void play() {
    System.out.println("Porcelain Doll is delicate, be gentle!");
  }
}