public class Barbie extends Doll {
  public Barbie(String _name, double _price){
    super(_name, "Plastic", _price);
  }
  
  public void play() {
    System.out.println("Barbie sings: I'm a Barbie girl in a Barbie world!");
  }
}
