public class Doll {
  private String name;
  private String material;
  private double price;

  public Doll(String _name, String _material, double _price) {
    name = _name;
    material = _material;
    price = _price;
  }

  public String toString() {
    return name;
  }

  public void play() {
    System.out.println("I don't know. How to play");
  }

  public void displayInfo(){
    System.out.println(String.format("Name: %s\nMaterial: %s\nPrice $%s", name, material, price));
  }

  public boolean isFragile(){
    return material == "Porcelain" || material == "Glass";
  }
}
