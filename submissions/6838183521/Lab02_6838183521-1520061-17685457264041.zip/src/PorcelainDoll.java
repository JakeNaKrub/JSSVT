public class PorcelainDoll extends Doll {

    PorcelainDoll(String name, double price) {
        super(name, "Porcelain", price);
    }

    @Override
    public void play() {
        System.out.println("Porcelain Doll is delicate, be gentle!");
    }
}
