public class PorcelainDoll extends Doll {

    public PorcelainDoll(String name, double price) {
        super(name, "Porcelain", price);
    }

    @Override
    public void play() {
        System.out.println("Porcelain Dolls are delicate, so be gentle!");
    }
}