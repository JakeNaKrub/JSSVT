public class PorcelainDoll extends Doll {
    public PorcelainDoll(String name, Float price){
        super(name, "Glass", price);
    }
    public void play() {
    System.out.println("Porcelain Doll is delicate, be gentle!");
}


}
