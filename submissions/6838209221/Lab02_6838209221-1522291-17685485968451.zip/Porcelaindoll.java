public class Porcelaindoll extends Doll {
    public Porcelaindoll(String name, double price){
        super(name, "Porcelain", price);
    }
    
    public void play(){
        System.out.println("Porcelain Doll is delicate, be gentle!");
    }
}