public class Barbie extends Doll {
    public Barbie(String name, Float price) {
        super(name, "Porcelain", price);
    }

    public void play(){
        System.out.println("Barbie sings: I'm a Barbie girl in a Barbie world!");
    }


    


}
