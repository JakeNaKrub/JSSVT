public class Barbie extends Doll{
    private String name;
    private float price;

    public Barbie(String name, float price){
        super(name, "Plastic", price);
    }

    public String toString(){
        return this.name;
    }

    @Override
    public void play(){
        System.out.println("Barbie sings: I'm a Barbie girl in a Barbie world!");
    }
}
