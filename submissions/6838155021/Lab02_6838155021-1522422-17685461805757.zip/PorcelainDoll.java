public class PorcelainDoll extends Doll{
    private String name;
    private float price;

    public PorcelainDoll(String name, float price){
        super(name, "Porcelain", price);
    }

    public String toString(){
        return this.name;
    }

    @Override
    public void play(){
        System.out.println("Porcelain Doll is delicate, be gentle!");
    }
}
