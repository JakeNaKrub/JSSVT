public class TeddyDoll extends Doll{
    private String name;
    private float price;

    public TeddyDoll(String name, float price){
        super(name, "Fur", price);
    }

    public String toString(){
        return this.name;
    }

    @Override
    public void play(){
        System.out.println("Teddy Doll says: Hug me!");
    }
}
