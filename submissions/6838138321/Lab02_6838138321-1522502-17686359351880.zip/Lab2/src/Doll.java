public class Doll {
    private String name;
    private String material;
    private double price;

    public Doll(String name, String material, double price) {
        this.name = name;
        this.material = material;
        this.price = price;
    }

    public String toString() {
        return this.name;
    }

    public void play() {
        System.out.println("I don't know. How to play");
    }

    public void displayInfo(){
        System.out.printf("Name: %s%nMaterial: %s%nPrice $%.2f%n",name, material,price);
    }

    public boolean isFragile(){
        if (material.equals("Porcelain") || material.equals("Glass")){
            return true;
        }else{
            return false;
        }
    }
}