public class Doll {
    private String name;
    private String material;
    private double price;

    public Doll(String name, double price){
        this.name = name;
        this.material = "blank";
        this.price = price;
    }

    public String toString() {
        return "Doll name: " + this.name;
    }

    public void play() {
        System.out.println("I don't know. How to play");
    }

    public void displayInfo() {
        System.out.println("Name: " + this.name + "\nMaterial: " + this.material + "\nPrice: $" + this.price);
    }

    public boolean isFragile() {
        if ((this.material == "Porcelain") || (this.material == "Glass")) {
            return true;
            }
        return false;
    }

    public void setMaterial(String material) {
        this.material = material;
    }
}
