package Lab2;

public class Doll {
	private String name;
	private String material;
	private double price;
	
	//constructor (initializing objects)
	public Doll(String name, String material, double price) {
		this.name = name;
		this.material = material;
		this.price = price;
	}
	
	//toString() special method in java..when u print an object, java calls this method.
	public String toString() {
		return name;
	}
	
	//method
	public void play() {
		System.out.println("I don't know. How to play");
	}

	public void displayInfo() {
		System.out.println("Name: " + name);
		System.out.println("Material: " + material);
		System.out.println("Price: $"+ price);
	}
	
	public boolean isFragile() {
		return material.equals("Porcelain") || material.equals("Glass");
	}
}