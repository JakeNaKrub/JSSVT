public class Doll {
    private final String name;
    private final String material;
    private final double price;

    public Doll(String name, String material, double price){
            this.name = name;
            this.material = material;
            this.price = price;
    }

    @Override
    public String toString(){
        return name;
    }

    public void play(){
        System.out.println("I don't know. How to play");
    }

    public void displayInfo(){
        System.out.println("Name: " + name);
        System.out.println("Material: " + material);
        System.out.println("Price: $" + price);
    }

    public boolean isFragile(){
        return material.equals("Porcelain") || material.equals("Glass");
    }
}