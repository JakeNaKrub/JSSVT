public class Doll {
    private String name;
    private String material;
    private float price;

    public Doll(String name, String material, float price) {
        this.name = name;
        this.material = material;
        this.price = price;
        
        
    }
    public String toString() {
        return this.name;
    }
    public void play() {
        System.out.println("I don't know how to play"); 
    }

    public void displayInfo(){
        System.out.println("Name: "+this.name);
        System.out.println("Material: "+this.material);
        System.out.println("Price: "+this.price);
    }

    public boolean isFragile(){
        if (this.material.equals("porcelain") || this.material.equals("glass")) {
            return true;
        } else {
            return false;
        }

    }
}