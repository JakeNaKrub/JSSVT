public class TeddyDoll extends Doll {
    public TeddyDoll(String name,float price){
        super(name,"Plastic",price); 
    }
    public void play(){
        System.out.println("Barbie sings: Hug me!");
    }
}