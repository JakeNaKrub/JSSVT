public class PorcelainDoll extends Doll {
    public PorcelainDoll(String name,float price){
        super(name,"Plastic",price); 
    }
    public void play(){
        System.out.println("Porcelain Doll is delicarw, be gentle");
    }
}