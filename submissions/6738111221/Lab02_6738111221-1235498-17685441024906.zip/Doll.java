package one;

public class Doll {
	private String name;
	private String material;
	private Float price;
	
	public Doll (String name, Float price) {
		this.name = name;
		this.price = price;
	}
	
	public String toString() {
		return this.name;
	}
	
	public void play() {
		System.out.println("I don't know. How to play");
	}
	
	public void displayInfo() {
		System.out.println("Name: " + this.name);
		System.out.println("Material: " + this.material);
		System.out.println("Price: $" + this.price);
	}
	
	public Boolean isFragile() {
		if (this.material.equals("Porcelain") || this.material.equals("Glass")) {
			return true;
		}
		return false;
	}
	
	public void setMaterial(String material) {
		this.material = material;
	}
	
}
